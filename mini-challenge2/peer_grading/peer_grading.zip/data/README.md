# Daten

Hier befinden sich die Daten für die gbsv Mini Challenge 2

## image

Unter image befinden sich die Daten welche verwendet wurden, um die Aufgabentellungen zu lösen.

### Datenquelle

| Datei                      | Beschreibung                                                                           |
| -------------------------- | -------------------------------------------------------------------------------------- |
| `image/handy-entons.jpg`   | https://de.wallpapers.com/wallpapers/gemustertes-psyduck-telefon-0x2cpj2gzgd0yhtj.html |
| `image/wilde-entons.jpg`   | https://wallpapers.com/wallpapers/psyducks-in-waterfalls-6stwq6myyaxyjmxc.html         |
| `signaldaten-snapshot.jpg` | Screenshot aus dem Notebook                                                            |
| `keypoint_imageX.jpg`      | Selber erstellte Fotos                                                                 |

## export

Hier befinden sich die exportierten Bilder die aus der Challenge entstanden sind.


